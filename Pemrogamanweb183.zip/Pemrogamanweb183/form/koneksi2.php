<?php
$host = "localhost"; 
$user = "root"; 
$pass = ""; 
$dbname = "registration_db"; 

// Membuat koneksi
$conn = new mysqli($host, $user, $pass, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Memeriksa apakah form di-submit dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form dan sanitasi input
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $asal_sekolah = trim($_POST['asal_sekolah']);
    $no_telepon = trim($_POST['no_telepon']);
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $kelas = $_POST['kelas'];
    $gender = $_POST['gender'];
    $alamat = trim($_POST['alamat']);
    $nama_orangtua = trim($_POST['nama_orangtua']);
    $pekerjaan_orangtua = trim($_POST['pekerjaan_orangtua']);
    $program_kursus = trim($_POST['program_kursus']);
    $hari_kursus = $_POST['hari_kursus'];
    $waktu_kursus = $_POST['waktu_kursus'];

    // Menyimpan data ke tabel dengan prepared statements
    $stmt = $conn->prepare("INSERT INTO pendaftaran (nama_lengkap, asal_sekolah, no_telepon, tanggal_lahir, kelas, gender, alamat, nama_orangtua, pekerjaan_orangtua, program_kursus, hari_kursus, waktu_kursus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    // Memeriksa jika statement berhasil dibuat
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }
    
    // Mengikat parameter
    $stmt->bind_param("ssssssssssss", $nama_lengkap, $asal_sekolah, $no_telepon, $tanggal_lahir, $kelas, $gender, $alamat, $nama_orangtua, $pekerjaan_orangtua, $program_kursus, $hari_kursus, $waktu_kursus);

    // Mengeksekusi statement dan menangani hasil
    if ($stmt->execute()) {
        echo "<script>alert('Pendaftaran berhasil!'); window.location.href='index.html';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='index.html';</script>";
    }

    // Menutup statement
    $stmt->close();
}

// Menutup koneksi
$conn->close();
?>
