<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Konfigurasi koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pemweb183";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah form telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil input dari form
    $username_input = trim($_POST['username']);
    $password_input = trim($_POST['password']);

    // Query untuk mencari username dan password di database
    $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username_input, $password_input);
    $stmt->execute();
    $result = $stmt->get_result();

    // Cek apakah kombinasi username dan password cocok
    if ($result->num_rows > 0) {
        // Set session dan arahkan ke halaman Home
        $_SESSION['username'] = $username_input;
        session_regenerate_id();

        header("Location: Home.html");
        exit();
    } else {
        echo "Username atau password salah!";
    }

    // Tutup statement dan koneksi
    $stmt->close();
}
$conn->close();
?>
