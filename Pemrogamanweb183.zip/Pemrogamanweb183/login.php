<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil input dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk memeriksa apakah username dan password cocok
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->store_result();
    
    // Cek apakah ada baris yang cocok
    if ($stmt->num_rows > 0) {
        echo "Login berhasil!";
        // Anda dapat menambahkan sesi di sini jika diperlukan
        // Contoh: $_SESSION['username'] = $username;
        header("Location: Home.html"); // Redirect ke halaman berikutnya
        exit();
    } else {
        echo "Username atau password salah!";
    }
    
    // Tutup statement
    $stmt->close();
}

// Tutup koneksi
$conn->close();
?>
